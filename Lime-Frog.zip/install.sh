#!/bin/bash
set -e

echo "=== SEO Checker - Linux Production Install ==="

# Проверка root прав
if [ "$EUID" -ne 0 ]; then
    echo "Ошибка: запустите с sudo"
    echo "Использование: sudo ./install.sh"
    exit 1
fi

# Переменные
APP_DIR="/opt/seo-checker"
APP_USER="www-data"
VENV_DIR="$APP_DIR/venv"
SERVICE_NAME="seo-checker"

echo "[1/7] Установка системных пакетов..."
apt-get update -qq
apt-get install -y python3 python3-pip python3-venv nginx ufw

echo "[2/7] Создание директории приложения..."
mkdir -p "$APP_DIR"
cp -r . "$APP_DIR/"
chown -R $APP_USER:$APP_USER "$APP_DIR"

echo "[3/7] Создание виртуального окружения..."
sudo -u $APP_USER python3 -m venv "$VENV_DIR"
sudo -u $APP_USER "$VENV_DIR/bin/pip" install --upgrade pip
sudo -u $APP_USER "$VENV_DIR/bin/pip" install -r "$APP_DIR/requirements.txt"
sudo -u $APP_USER "$VENV_DIR/bin/pip" install gunicorn

echo "[4/7] Настройка Nginx..."
cp "$APP_DIR/nginx.example.conf" /etc/nginx/sites-available/seo-checker
ln -sf /etc/nginx/sites-available/seo-checker /etc/nginx/sites-enabled/seo-checker
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

echo "[5/7] Создание systemd сервиса..."
cat > /etc/systemd/system/$SERVICE_NAME.service <<EOF
[Unit]
Description=SEO Checker (Gunicorn)
After=network.target

[Service]
Type=notify
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$VENV_DIR/bin"
ExecStart=$VENV_DIR/bin/gunicorn -c $APP_DIR/gunicorn.conf.py app:app
ExecReload=/bin/kill -s HUP \$MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable $SERVICE_NAME
systemctl restart $SERVICE_NAME

echo "[6/7] Настройка Firewall (UFW)..."
ufw --force enable
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw reload

echo "[7/7] Проверка статуса..."
systemctl status $SERVICE_NAME --no-pager || true
nginx -t

echo ""
echo "✅ Установка завершена!"
echo ""
echo "Сервис запущен на http://$(hostname -I | awk '{print $1}')"
echo ""
echo "Управление сервисом:"
echo "  sudo systemctl status $SERVICE_NAME"
echo "  sudo systemctl restart $SERVICE_NAME"
echo "  sudo systemctl logs -f $SERVICE_NAME  # просмотр логов"
echo ""
echo "Nginx логи:"
echo "  /var/log/nginx/access.log"
echo "  /var/log/nginx/error.log"
